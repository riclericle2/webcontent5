<?php 	

$localhost = "database-1.c2fj7fxdnxzk.ap-southeast-1.rds.amazonaws.com";
$username = "admin";
$password = "L1993Lapho";
$dbname = "store";

// db connection
$connect = new mysqli($localhost, $username, $password, $dbname);
// check connection
if($connect->connect_error) {
  die("Connection Failed : " . $connect->connect_error);
} else {
  // echo "Successfully connected";
}

?>