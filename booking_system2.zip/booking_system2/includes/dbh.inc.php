<?php

$servername = "database-1.c2fj7fxdnxzk.ap-southeast-1.rds.amazonaws.com";
$dBUsername = "admin";
$dBPassword = "L1993Lapho";
$dBName = "loginsystem";

$conn = mysqli_connect($servername, $dBUsername, $dBPassword, $dBName);

if (!$conn){
    die("Connection failed:" .mysqli_connect_error());
}
?>

